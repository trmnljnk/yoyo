/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_pointer.c                                       :+:    :+:            */
/*                                                     +:+                    */
/*   By: e21877 <e21877@student.codam.nl>             +#+                     */
/*                                                   +#+                      */
/*   Created: 2022/07/12 19:33:35 by e21877        #+#    #+#                 */
/*   Updated: 2022/07/13 22:18:26 by e21877        ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

int	main(void)
{
	int	temp;
	int	*ptr;

	temp = 22;
	ptr = &temp;
	printf("temp: %d\n", temp);
	printf("temp through pointer: %d\n", *ptr);
	temp = 35;
	printf("temp: %d\n", temp);
	printf("temp through pointer: %d\n", *ptr);
	*ptr = 39;
	printf("temp: %d\n", temp);
	printf("temp through pointer: %d\n", *ptr);
	temp++;
	printf("temp: %d\n", temp);
	printf("temp through pointer: %d\n", *ptr);
	(*ptr)++;
	printf("temp: %d\n", temp);
	printf("temp through pointer: %d\n", *ptr);
	return (0);
}
