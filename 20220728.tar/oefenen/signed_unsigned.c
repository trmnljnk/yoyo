

#include <stdio.h>

void	main(void)
{
	char	c;

	c = 'A';
	printf("%d\n", c);
	printf("%c\n", c);
}
