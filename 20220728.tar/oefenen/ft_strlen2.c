#include <stdio.h>

int		ft_strlen(char *str)
{
	int i;

	i = 0;
	while (str[i])
	{
		i++;
	}
	return (i);
}

// int		ft_strlen(char *str);

int		main(void)
{
	char *str;

	str = "abcdefghijklmnopqrst";
	printf("Count is (20): %d\n", ft_strlen(str));
}
