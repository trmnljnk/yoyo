/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   main.c                                             :+:    :+:            */
/*                                                     +:+                    */
/*   By: pvissers <marvin@codam.nl>                   +#+                     */
/*                                                   +#+                      */
/*   Created: 2022/07/24 13:31:56 by pvissers      #+#    #+#                 */
/*   Updated: 2022/07/24 14:27:47 by pvissers      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

void	ft_putstr(char *str);
void	ft_putchar(char c);

int	main(void)
{
	ft_putstr("gjhgjhf");
	// ft_putchar('z');
	// ft_putchar('\n');
	return (0);
}
