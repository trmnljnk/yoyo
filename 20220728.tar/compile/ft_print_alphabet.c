/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_putchar.c                                       :+:    :+:            */
/*                                                     +:+                    */
/*   By: pvissers <marvin@codam.nl>                   +#+                     */
/*                                                   +#+                      */
/*   Created: 2022/07/15 14:27:13 by pvissers      #+#    #+#                 */
/*   Updated: 2022/07/24 13:37:10 by pvissers      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

void	ft_print_alphabet(void)
{
	char	i;

	i = 'a';
	while (i <= 'z')
	{
		ft_putchar(i);
		i++;
	}
}

int	main(void)
{
	ft_print_alphabet();
	return (0);
}
