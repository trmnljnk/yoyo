/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_strlowcase.c                                    :+:    :+:            */
/*                                                     +:+                    */
/*   By: pvissers <marvin@codam.nl>                   +#+                     */
/*                                                   +#+                      */
/*   Created: 2022/07/19 14:46:08 by pvissers      #+#    #+#                 */
/*   Updated: 2022/07/19 15:23:26 by pvissers      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

/* Create a function that transforms every letter to lowercase. */

// #include <stdio.h>

char	*ft_strlowcase(char *str)
{
	unsigned int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= 'A' && str[i] <= 'Z')
		{
			str[i] = str[i] + 32;
		}
		i++;
	}
	return (str);
}

// int	main(void)
// {
// 	char	str[] = "JKKghjGHJ";

// 	printf(":%s:\n", str);
// 	ft_strlowcase(str);
// 	printf(":%s:\n", str);
// 	return (0);
// }