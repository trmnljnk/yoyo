/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_strcpy.c                                        :+:    :+:            */
/*                                                     +:+                    */
/*   By: pvissers <pvissers@codam.nl>                 +#+                     */
/*                                                   +#+                      */
/*   Created: 2022/07/18 08:55:32 by pvissers      #+#    #+#                 */
/*   Updated: 2022/07/18 12:53:19 by pvissers      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

#include <unistd.h>

char	*ft_strcpy(char *dest, char *src)
{
	char *dest_backup = dest;

	while(*src != '\0')
	{
		*dest = *src;
		src++;
		dest++;
	}
	*dest = '\0';
	return (dest_backup);
}

int	main(void)
{
	char source_str[] = "www.linuxhint.com";
	char destination_str[20];

	printf("Before calling user defined string copy function : \n\n");
	printf("\tSource String       = %s\n", source_str);
	printf("\tDestination String  = %s\n\n", destination_str);

	ft_strcpy(destination_str, source_str);

	printf("After executing user defined string copy function : \n\n");
	printf("\tSource String       = %s\n", source_str);
	printf("\tDestination String  = %s\n\n", destination_str);
	return (0);

}
