#include <stdio.h>
char * strcpy_user_defined(char *dest, const char * src);

/* User defined version of strcpy() function */
char * strcpy_user_defined(char *dest, const char * src)
{
    char * dest_backup = dest;
   
    while(*src != '\0')    /* Iterate until '\0' is found.*/
    {
        *dest = *src;     /* Copy source char to destination */
        src++;            /* Increment source pointer */
        dest++;         /* Increment destination pointer */
    }
   
    *dest = '\0';         /* Insert '\0' in destination explicitly*/
   
    return dest_backup;
}
   
int main(void)
{
    char source_str[] = "www.linuxhint.com";
    char destination_str[30];
   
    printf("Before calling user defined string copy function : \n\n");
    printf("\tSource String       = %s\n", source_str);
    printf("\tDestination String  = %s\n\n", destination_str);
   
    /* Calling user defined string copy function */
    strcpy_user_defined(destination_str, source_str);  
   
    printf("After executing user defined string copy function : \n\n");
    printf("\tSource String       = %s\n", source_str);
    printf("\tDestination String  = %s\n\n", destination_str);
   
    return (0);
}