/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_strcpy.c                                        :+:    :+:            */
/*                                                     +:+                    */
/*   By: pvissers <pvissers@codam.nl>                 +#+                     */
/*                                                   +#+                      */
/*   Created: 2022/07/18 08:55:32 by pvissers      #+#    #+#                 */
/*   Updated: 2022/07/20 11:55:47 by pvissers      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>

char	*ft_strcpy(char	*dest, char	*src)
{
	int	i;

	i = 0;
	while (src[i])
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (dest);
}

int	main(void)
{
	char	src[] = "teststring";
	char	dest[] = "";

	printf(":%s:\n", dest);
	ft_strcpy(dest, src);
	printf(":%s:\n", dest);
	return (0);
}