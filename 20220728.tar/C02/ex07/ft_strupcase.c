/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_strupcase.c                                     :+:    :+:            */
/*                                                     +:+                    */
/*   By: pvissers <marvin@codam.nl>                   +#+                     */
/*                                                   +#+                      */
/*   Created: 2022/07/19 12:03:24 by pvissers      #+#    #+#                 */
/*   Updated: 2022/07/19 15:19:30 by pvissers      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

/* Create a function that transforms every letter to uppercase. */

// #include <stdio.h>

char	*ft_strupcase(char *str)
{
	unsigned int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= 'a' && str[i] <= 'z')
		{
			str[i] = str[i] - 32;
		}
		i++;
	}
	return (str);
}

// int	main(void)
// {
// 	char	str[] = "tesTstring";

// 	printf(":%s:\n", str);
// 	ft_strupcase(str);
// 	printf(":%s:\n", str);
// 	return (0);
// }