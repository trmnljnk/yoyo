/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_str_is_uppercase.c                              :+:    :+:            */
/*                                                     +:+                    */
/*   By: pvissers <marvin@codam.nl>                   +#+                     */
/*                                                   +#+                      */
/*   Created: 2022/07/19 10:32:44 by pvissers      #+#    #+#                 */
/*   Updated: 2022/07/20 09:42:19 by pvissers      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_uppercase(char *str)
{
	unsigned int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] < 'A' || str[i] > 'Z')
			return (0);
		++i;
	}
	return (1);
}

int	main(void)
{
	char	str[] = "GHJGHjFGHFGHF";

	printf("%d", ft_str_is_uppercase(str));
	return (0);
}