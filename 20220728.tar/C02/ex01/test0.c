/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_strncpy.c                                       :+:    :+:            */
/*                                                     +:+                    */
/*   By: pvissers <pvissers@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2022/07/18 12:32:58 by pvissers      #+#    #+#                 */
/*   Updated: 2022/07/18 13:16:10 by pvissers      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

char *strncpy(char * restrict dest, const char * restrict src, size_t n);



/* copying the string from an array “src” to the array “dest” */

/*int	main(void)
{
	char src[] = "Aticleworld";
	// The destination string size is 14.
	char dest[16] = {0};
	// copying n bytes of src into dest.
	strncpy(dest, src, 12);
	printf("Copied string: %s\n", dest);
	return (0);
}*/


/* If the source buffer is longer than the number of bytes that you want to 
   copy, then no null character is implicitly appended at the end of the 
   destination buffer. */

/*int	main(void)
{
	char src[12] = "Aticleworld";
	// The destination string size is 14.
	char dest[12];
	// copying 5 bytes of src into dest.
	strncpy(dest, src, 5);
	printf("Copied string: %s\n", dest);
	return (0);
}*/

/*int	main(void)
{
	char src[] = "Aticleworld";
	// The destination string size is 10.
	char dest[10];
	// copying 5 bytes of src into dest.
	strncpy(dest, src, 5);
	dest[5] = '\0'; //Append null character
	printf("Copied string: %s\n", dest);
	return 0;
}*/

/* If the source string is shorter than n characters (number of characters want
 * to copy), then the destination array is padded with zeros until a total of n
 * characters have been written to it.  */

int main(void)
{
    char src[] = "Hi";
    // The destination string size is 10.
    char dest[10];
    // copying 5 bytes of src into dest.
    strncpy(dest, src, 5);
    printf("Copied string: %s\n", dest);
    return 0;
}
