/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_str_is_printable.c                              :+:    :+:            */
/*                                                     +:+                    */
/*   By: pvissers <marvin@codam.nl>                   +#+                     */
/*                                                   +#+                      */
/*   Created: 2022/07/19 10:48:26 by pvissers      #+#    #+#                 */
/*   Updated: 2022/07/20 11:57:19 by pvissers      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

/* Create a function that returns 1 if the string given as a parameter contains
 * only printable characters, and 0 if it contains any other character.  */

int	ft_str_is_printable(char *str)
{
	unsigned int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] < 32)
			return (0);
		++i;
	}
	return (1);
}

int	main(void)
{
	char	str[] = "fd				shgafdhgfg";

	printf("%d", ft_str_is_printable(str));
	return (0);
}