/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_atoi.c                                          :+:    :+:            */
/*                                                     +:+                    */
/*   By: pvissers <marvin@codam.nl>                   +#+                     */
/*                                                   +#+                      */
/*   Created: 2022/07/27 13:26:39 by pvissers      #+#    #+#                 */
/*   Updated: 2022/07/27 16:07:42 by pvissers      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>



int	ft_atoi(char *str)
{
	int	result;
	int	sign;

	result = 0;
	sign = 1;
	while (*str == 32 || (*str >= 9 && *str <= 13))
	{
		str++;
	}
	if (*str == '-')
	{
		sign *= -1;
	}
	if (*str == '-' || *str == '+')
	{
		str++;
	}
	while (*str >= '0' && *str <= '9')
	{
		result = result * 10 + *str - '0';
		str++;
	}
	return (result * sign);
}

// int	main(int ac, char **av)
// {
// 	int mine;
// 	int org;
// 	if (ac == 2)
// 	{
// 		mine = ft_atoi(av[1]);
// 		printf("Atoi official: %d", atoi("----+--1234fg"));
// 		org  = atoi(av[1]);
// 		printf("mine: %d | org: %d\n", mine, org);
// 	}
// 	printf("%s:", av[1]);
// 	return (0);
// }

int main(void)
{
	char str[100] = "   ----+--1234fg";
	printf("str: %s\n", str);
	printf("My result: %d", ft_atoi(str));
	// printf("Atoi result: %d", atoi("1234fg"));
	return(0);
	
}
