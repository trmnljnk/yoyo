#include <stdio.h>
#include <limits.h>


int main()
{
    printf("Minimum Int value:%d\n", INT_MIN);
    printf("Maximum Int value:%d\n", INT_MAX);
    return 0;
}
