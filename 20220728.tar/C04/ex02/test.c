
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>

int	main(void)
{
	char ch;
	signed char ch1;
	unsigned char ch2;

	int	i1;
	short int i2;
	long int i3;
	long long int i4;

	unsigned int i5;
	unsigned short int i6;
	unsigned long int i7;
	unsigned long long int i8;

	printf("Character uses %d bits\n", sizeof(char) * 8);

	printf("Integer uses %d bits\n", sizeof(int) * 8);

	printf("Short integer uses %d bits\n", sizeof(short int) * 8);

	printf("Long integer uses %d bits\n", sizeof(long int) * 8);
	
	printf("Long long integer uses %d bits\n\n", sizeof(long long int) * 8);

	printf("Signed character from %d to %d\n", SCHAR_MIN, SCHAR_MAX);

	printf("Unsigned character from %d to %u\n", 0, UCHAR_MAX);

	printf("Signed short integer from %d to %d\n", SHRT_MIN, SHRT_MAX);

	printf("Unsigned short integer from %d to %u\n", 0, USHRT_MAX);

	printf("Signed integer from %d to %d\n", (-INT_MAX -1), INT_MAX);

	printf("Unsigned integer from %d to %u\n", 0, UINT_MAX);

	printf("Signed long integer from %ld to %ld\n", (-LONG_MAX -1L), LONG_MAX);

	printf("Unsigned long integer minimum %d to %lu\n", 0, ULONG_MAX);

	printf("Signed long long integer from %lld to %lld\n", (-LLONG_MAX - 1L), LLONG_MAX);

	printf("Unsigend long long integer from %d to %llu\n", 0, ULLONG_MAX);

	return(EXIT_SUCCES);
}





