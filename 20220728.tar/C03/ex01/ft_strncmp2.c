/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_strncmp2.c                                      :+:    :+:            */
/*                                                     +:+                    */
/*   By: pvissers <marvin@codam.nl>                   +#+                     */
/*                                                   +#+                      */
/*   Created: 2022/07/20 13:43:30 by pvissers      #+#    #+#                 */
/*   Updated: 2022/07/22 14:16:47 by pvissers      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

int	ft_strncmp(char *s1, char *s2, unsigned int n)
{
	int	i;

	i = 0;
	while (n > 0)
	{
		while (s1[i] == s2[i] && s1[i] != '\0' && s2[i] != '\0')
	}
	
	
		i++;
	return (s1[i] - s2[i]);
}

int	main(void)
{
	char	s1[] = "jhghjgjhl";
	char	s2[] = "jhgHjgjhl";
	int		size = 0;

	printf("%d\n", ft_strncmp(s1, s2, size));
	printf("%d\n", strncmp(s1, s2, size));
	return (0);
}