
int	main(void)
{
	char	s1[] = "jHghjgjhl";
	char	s2[] = "jhghjgJhl";
	int		size = 5;

	ft_strncmp(s1, s2, size);
	return (0);
}
