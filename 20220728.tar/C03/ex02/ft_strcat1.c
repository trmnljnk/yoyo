/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_strcat.c                                        :+:    :+:            */
/*                                                     +:+                    */
/*   By: pvissers <marvin@codam.nl>                   +#+                     */
/*                                                   +#+                      */
/*   Created: 2022/07/20 17:14:45 by pvissers      #+#    #+#                 */
/*   Updated: 2022/07/20 18:50:54 by pvissers      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

/* Reproduce the behavior of the function strcat (man strcat). */

char	*ft_strcat(char *dest, char *src)
{
	char	*start = dest;

	while (*dest != '\0')
	{
		dest++;
	}
	while (*src != '\0')
	{
		*dest = *src;
		dest++;
		src++;
	}
	*dest = '\0';
	return (start);
}

int	main(void)
{
	char	src[20] = "Hello there ";
	char	dest[] = "Paola";

	ft_strcat(dest, src);
	printf("%s", start);
	return (0);
}
