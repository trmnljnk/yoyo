int main(void)
{
	char src[50], dest[50];

	ft_strcpy(src, "This is source");
	ft_strcpy(dest, "This is destination");

	ft_strcpy(src, dest);
	printf("%s\n%s\n", src, dest);
	ft_strcat(dest, src);

	printf("Final destination string : |%s|", dest);
	return (0);
}