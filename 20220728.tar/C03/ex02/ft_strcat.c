/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_strcat.c                                        :+:    :+:            */
/*                                                     +:+                    */
/*   By: pvissers <pvissers@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2022/07/21 09:57:13 by pvissers      #+#    #+#                 */
/*   Updated: 2022/07/21 16:29:25 by pvissers      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>
// #include <string.h>

char	*ft_strcat(char *dest, char *src)
{
	unsigned int	i;
	unsigned int	j;

	i = 0;
	while (dest[i] != '\0')
		i++;
	j = 0;
	while (src[j] != '\0')
	{
		dest[i + j] = src[j];
		j++;
	}
	dest[i + j] = '\0';
	return (dest);
}

// int main(void)
// {
// 	char src[10]	= "abc";
// 	char dest[10]	= "123";

// 	printf("concatenated strings: %s\n", ft_strcat(dest, src));
// 	return (0);
// }