/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_strcmp2.c                                       :+:    :+:            */
/*                                                     +:+                    */
/*   By: pvissers <marvin@codam.nl>                   +#+                     */
/*                                                   +#+                      */
/*   Created: 2022/07/20 09:33:32 by pvissers      #+#    #+#                 */
/*   Updated: 2022/07/21 19:04:17 by pvissers      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>

/* Reproduce the behavior of the function strcmp (man strcmp). */

int	ft_strcmp(char *s1, char *s2)
{
	unsigned int	i;

	i = 0;
	while (s1[i] == s2[i] && s1[i] != '\0' && s2[i] != '\0')
		i++;
	return (s1[i] - s2[i]);
}

/* functions return an integer greater than, equal to, or less than 0 */

int	main(void)
{
	char	s1[] = "asaksfgjh";
	char	s2[] = "asaksFgjh";

	printf("%d", ft_strcmp(s1, s2));
	return (0);
}
