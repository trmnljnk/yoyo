/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_strcmp.c                                        :+:    :+:            */
/*                                                     +:+                    */
/*   By: pvissers <marvin@codam.nl>                   +#+                     */
/*                                                   +#+                      */
/*   Created: 2022/07/20 09:33:32 by pvissers      #+#    #+#                 */
/*   Updated: 2022/07/22 12:20:12 by pvissers      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

/* Reproduce the behavior of the function strcmp (man strcmp). */

int	ft_strcmp(char *s1, char *s2)
{
	unsigned int	i;

	i = 0;
	while (s1[i] == s2[i] && s1[i] != '\0' && s2[i] != '\0')
	{
		i++;
	}
	return (s1[i] - s2[i]);
}

int	main(void)
{
	char	s1[15] = "fgdfgd";
	char	s2[15] = "fgdf\200d";
	printf("%s : %s\n", s1, s2);
	printf("%d\n", ft_strcmp(s1, s2));
	printf("-----------------------\n");
	printf("%d\n", strcmp(s1, s2));
	return (0);
}