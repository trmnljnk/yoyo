
/* functions return an integer greater than, equal to, or less than 0 */

int	main(void)
{
	char	s1[] = "asaksfGjh";
	char	s2[] = "asaksfgjh";

	printf("%d", ft_strcmp(s1, s2));
	return (0);
}



#include <string.h>
#include <stdio.h>

/* functions return an integer greater than, equal to, or less than 0 */

int	main(void)
{
	char	s1[] = "asaksFgjh";
	char	s2[] = "asaksfgjh";
	ft_strcmp(s1, s2);
	//printf("%d", ft_strcmp(s1, s2));
	return (0);
}
