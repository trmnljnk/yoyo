/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_swap.c                                          :+:    :+:            */
/*                                                     +:+                    */
/*   By: pvissers <pvissers@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2022/07/14 10:55:58 by pvissers      #+#    #+#                 */
/*   Updated: 2022/07/14 18:09:31 by pvissers      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_swap(int *a, int *b)
{
	int	temp;

	temp = *a;
	*a = *b;
	*b = temp;
}

// int	main(void)
// {
// 	int	a;
// 	int	b;

// 	a = 10;
// 	b = 33;
// 	printf("Values a & b before swap:\t a = %d and b = %d\n", a, b);
// 	ft_swap(&a, &b);
// 	printf("Values a & b after swap:\t a = %d and b = %d\n", a, b);
// }
