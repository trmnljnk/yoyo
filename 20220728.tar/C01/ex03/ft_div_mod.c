/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_div_mod.c                                       :+:    :+:            */
/*                                                     +:+                    */
/*   By: pvissers <pvissers@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2022/07/14 11:50:02 by pvissers      #+#    #+#                 */
/*   Updated: 2022/07/14 18:13:48 by pvissers      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_div_mod(int a, int b, int *div, int *mod)
{
	*div = a / b;
	*mod = a % b;
}

// int	main(void)
// {
// 	int	a;
// 	int	b;
// 	int	div;
// 	int	mod;
// 	int	*ptr1;
// 	int	*ptr2;

// 	a = 20;
// 	b = 5;
// 	ptr1 = &div;
// 	ptr2 = &mod;
// 	ft_div_mod(a, b, ptr1, ptr2);
// 	printf("Result\t (11)= %d\n", div);
// 	printf("Rest\t (27)= %d\n", mod);
// }
