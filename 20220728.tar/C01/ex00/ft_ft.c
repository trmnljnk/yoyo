/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_ft.c                                            :+:    :+:            */
/*                                                     +:+                    */
/*   By: pvissers <pvissers@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2022/07/14 10:41:22 by pvissers      #+#    #+#                 */
/*   Updated: 2022/07/14 18:03:38 by pvissers      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

void	ft_ft(int *nbr)
{
	*nbr = 42;
}

// int	main(void)
// {
// 	int	a;
// 	int	*nbr;

// 	a = 21;
// 	nbr = &a;
// 	printf("Before (21): %d\n", a);
// 	ft_ft(nbr);
// 	printf("After  (42): %d\n", a);
// }
