/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_ultimate_div_mod.c                              :+:    :+:            */
/*                                                     +:+                    */
/*   By: pvissers <pvissers@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2022/07/14 11:53:17 by pvissers      #+#    #+#                 */
/*   Updated: 2022/07/14 18:16:18 by pvissers      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_ultimate_div_mod(int *a, int *b)
{
	int	div;
	int	mod;

	div = *a / *b;
	mod = *a % *b;
	*a = div;
	*b = mod;
}

// int	main(void)
// {
// 	int	a;
// 	int	b;
// 	int	*ptr1;
// 	int	*ptr2;

// 	a = 841;
// 	b = 74;
// 	ptr1 = &a;
// 	ptr2 = &b;
// 	ft_ultimate_div_mod(ptr1, ptr2);
// 	printf("Result\t (11)= %d\n", a);
// 	printf("Rest\t (27)= %d\n", b);
// }
