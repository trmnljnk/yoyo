#!/bin/bash
find . | wc -l | xargs echo