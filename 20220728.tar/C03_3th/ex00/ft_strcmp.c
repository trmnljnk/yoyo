/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_strcmp.c                                        :+:    :+:            */
/*                                                     +:+                    */
/*   By: pvissers <marvin@codam.nl>                   +#+                     */
/*                                                   +#+                      */
/*   Created: 2022/07/25 17:19:25 by pvissers      #+#    #+#                 */
/*   Updated: 2022/07/25 17:22:58 by pvissers      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>
// #include <string.h>

int	ft_strcmp(char *s1, char *s2)
{
	unsigned int	i;

	i = 0;
	while (s1[i] != '\0' && s2[i] != '\0')
	{
		if (s1[i] != s2[i])
			return (s1[i] - s2[i]);
		i++;
	}
	return (s1[i] - s2[i]);
}

// int	main(void)
// {
// 	char	s1[15] = "efwef";
// 	char	s2[15] = "efwf";

// 	printf("%s : %s\n", s1, s2);
// 	printf("%d\n", ft_strcmp(s1, s2));
// 	printf("-----------------------\n");
// 	printf("%d\n", strcmp(s1, s2));
// 	return (0);
// }