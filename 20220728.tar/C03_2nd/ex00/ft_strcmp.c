/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_strcmp.c                                        :+:    :+:            */
/*                                                     +:+                    */
/*   By: pvissers <marvin@codam.nl>                   +#+                     */
/*                                                   +#+                      */
/*   Created: 2022/07/25 09:37:29 by pvissers      #+#    #+#                 */
/*   Updated: 2022/07/25 13:44:25 by pvissers      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>
// #include <string.h>

int	ft_strcmp(char *s1, char *s2)
{
	unsigned int	i;

	i = 0;
	while (s1[i] != '\0' && s2[i] != '\0')
	{
		if (s1[i] != s2[i])
			return (s1[i] - s2[i]);
		i++;
	}
	if ((s1[i] == '\0' && s2[i] != '\0') || (s2[i] == '\0' && s1[i] != '\0'))
		return (s1[i] - s2[i]);
	return (0);
}

// int	main(void)
// {
// 	char	s1[15] = "fgdfd";
// 	char	s2[15] = "fgdfd";

// 	printf("%s : %s\n", s1, s2);
// 	printf("%d\n", ft_strcmp(s1, s2));
// 	printf("-----------------------\n");
// 	printf("%d\n", strcmp(s1, s2));
// 	return (0);
// }
