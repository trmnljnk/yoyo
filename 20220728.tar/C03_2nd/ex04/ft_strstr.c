/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_strstr.c                                        :+:    :+:            */
/*                                                     +:+                    */
/*   By: pvissers <marvin@codam.nl>                   +#+                     */
/*                                                   +#+                      */
/*   Created: 2022/07/25 10:35:53 by pvissers      #+#    #+#                 */
/*   Updated: 2022/07/25 14:01:49 by pvissers      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>

char	*ft_strstr(char *str, char *to_find)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	if (to_find[j] == '\0')
		return (str);
	while (str[i] != '\0')
	{
		while (str[i + j] == to_find[j] && str[i + j] != '\0')
		{
			j++;
			if (to_find[j] == '\0')
				return (str + i);
		}
		i++;
		j = 0;
	}
	return (str);
}

// int	main(void)
// {
// 	char aa[29] = "Ace the Technical Interviews";
// 	char bb[11] = "Technical";
// 	char	*a = aa;
// 	char	*b = bb;
// 	printf("%s: ", ft_strstr(a, b));
// 	return (0);
// }
