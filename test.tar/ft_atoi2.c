/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_atoi2.c                                         :+:    :+:            */
/*                                                     +:+                    */
/*   By: e21877 <e21877@student.codam.nl>             +#+                     */
/*                                                   +#+                      */
/*   Created: 2022/07/28 05:00:48 by e21877        #+#    #+#                 */
/*   Updated: 2022/07/28 05:11:09 by e21877        ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

int	ft_atoi(char *str)
{
	int	i;
	int	result;
	int	sign;

	i = 0;
	result = 0;
	sign = 1;
	while (str[i] == 32 || (*str > 8 && *str < 14))
	{
		i++;
	}
	if (str[i] == '-')
	{
		sign *= -1;
	}
	if (str[i] == '-' || str[i] == '+')
	{
		i++;
	}	
	while (str[i] >= '0' && str[i] <= '9')
	{
		result = result * 10 + str[i] - '0';
		i++;
	}
	result *= sign;
	return (result);
}

int	main(void)
{
	char	*str;

	str = "      ---+--+++2300fesfss65+2";
	printf("%d\n", ft_atoi(str));
	printf("%d\n", atoi(str));
}
