/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_atoi.c                                          :+:    :+:            */
/*                                                     +:+                    */
/*   By: ybayart <marvin@42.fr>                       +#+                     */
/*                                                   +#+                      */
/*   Created: 2019/08/05 04:18:16 by ybayart       #+#    #+#                 */
/*   Updated: 2022/07/28 05:04:01 by e21877        ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

int	ft_atoi(char *str)
{
	int		i;
	int		sign;
	int		result;

	i = 0;
	sign = 1;
	result = 0;
	while (str[i] == 32 || (*str >= 9 && *str <= 13))
	{
		i++;
	}
	while (str[i] == '-' || str[i] == '+')
	{
		if (str[i] == '-')
			sign *= -1;
		i++;
	}
	while (str[i] >= '0' && str[i] <= '9')
	{
		result = (result * 10) + (str[i] - '0');
		i++;
	}
	result *= sign;
	return (result);
}

int	main(void)
{
	char	*str;

	str = "      ---+--+++2300fesfss65+2";
	printf("%d\n", ft_atoi(str));
	printf("%d\n", atoi(str));
}
